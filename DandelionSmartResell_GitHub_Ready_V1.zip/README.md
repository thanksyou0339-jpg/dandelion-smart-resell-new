# Dandelion Smart Resell — GitHub-ready V1

یہ package GitHub repository میں upload کرنے کے لیے تیار ہے۔

1. `index.html` upload کریں۔
2. GitHub Pages enable کریں۔
3. ویب لنک کھولیں۔

نوٹ: یہ V1 browser localStorage استعمال کرتی ہے، اس لیے data اسی browser/device میں رہتا ہے۔ حقیقی multi-user online orders، secure admin login اور central database کے لیے backend/database الگ شامل کرنا ہوگا۔
Markaz کے لیے V1 official workflow کے مطابق order data تیار کرتی ہے؛ غیرمجاز automatic submission نہیں کرتی۔
